# pyctf

Package by NIH (https://megcore.nih.gov/index.php/Pyctf)

Edited and Fixed for EMG_MMG_Preprocessing
