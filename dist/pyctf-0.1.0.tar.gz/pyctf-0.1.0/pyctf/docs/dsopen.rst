Opening CTF datasets
====================
To open a CTF dataset, use ``dsopen``::

  import pyctf
  ds = pyctf.dsopen("dataset.ds")

``dsopen`` objects have the following methods:

.. autoclass:: pyctf.dsopen
    :members:
