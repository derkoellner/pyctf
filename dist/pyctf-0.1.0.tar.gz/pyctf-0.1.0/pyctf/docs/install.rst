Installation
============

The latest pyctf source can be found here: `pyctf <http://megcore.nih.gov/index.php/Pyctf>`_
